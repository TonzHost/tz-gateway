# TZ Gateway — Aplikasi Android

## Cara Dapat APK (Langkah Demi Langkah)

### 1. Buat Akun GitHub (gratis)
- Buka https://github.com
- Klik Sign Up → isi username, email, password

### 2. Buat Repository Baru
- Setelah login, klik tombol + di kanan atas → New repository
- Nama repo: `tz-gateway-app`
- Pilih: Public
- Klik Create repository

### 3. Upload Semua File Ini ke GitHub
- Di halaman repo, klik **uploading an existing file**
- Drag & drop semua file dan folder dari ZIP ini
- Klik Commit changes

### 4. Tunggu Build Otomatis (~5 menit)
- Klik tab **Actions** di repo kamu
- Lihat workflow **Build APK** sedang berjalan
- Tunggu sampai centang hijau ✅

### 5. Download APK
- Klik workflow yang sudah selesai
- Scroll ke bawah bagian **Artifacts**
- Klik **TonzGateway-APK** → download ZIP
- Extract ZIP → dapat file **app-debug.apk**

### 6. Install di HP Android
- Transfer APK ke HP (via WhatsApp/Telegram/kabel)
- Di HP: Pengaturan → Keamanan → aktifkan **Sumber tidak dikenal**
- Tap file APK → Install

---

## Cara Pakai Aplikasi

1. Buka aplikasi **TZ Gateway**
2. Muncul dialog → masukkan URL gateway server kamu:
   - VPS: `http://IP_SERVER:4000`
   - Vercel: `https://nama-project.vercel.app`
3. Klik **Simpan & Buka**
4. Login dengan password `Daton_189`

## Jika Mau Ganti URL Gateway
- Di dalam app, jika koneksi gagal → klik **Ganti URL Gateway**
- Atau restart app → tahan tombol back → keluar → buka lagi

---

## Spesifikasi
- Android minimal: 5.0 (Lollipop) ke atas
- Ukuran APK: ~3 MB
- Tidak butuh Google Play
