package com.tonzstore.gateway;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView       wv;
    private ProgressBar   pb;
    private LinearLayout  errLayout;
    private TextView      errMsg;
    private SharedPreferences prefs;

    private static final String PREF  = "gw";
    private static final String PREF_URL = "url";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs     = getSharedPreferences(PREF, MODE_PRIVATE);
        wv        = findViewById(R.id.webview);
        pb        = findViewById(R.id.progress);
        errLayout = findViewById(R.id.errorLayout);
        errMsg    = findViewById(R.id.errorMsg);

        setupWebView();

        String url = prefs.getString(PREF_URL, "");
        if (url.isEmpty()) {
            showSetupDialog();
        } else {
            open(url);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        wv.addJavascriptInterface(new Bridge(), "Android");

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                pb.setVisibility(View.VISIBLE);
                errLayout.setVisibility(View.GONE);
                wv.setVisibility(View.VISIBLE);
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                pb.setVisibility(View.GONE);
                injectCSS();
            }
            @Override
            public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    pb.setVisibility(View.GONE);
                    showErr("Tidak bisa terhubung ke gateway.\n\nPastikan:\n1. URL gateway benar\n2. Server gateway sedang berjalan\n3. HP terhubung ke internet/WiFi");
                }
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                pb.setProgress(p);
                pb.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) { return true; }
        });
    }

    private void injectCSS() {
        String js = "(function(){"
            + "var s=document.createElement('style');"
            + "s.innerHTML='"
            + "input,textarea,select{font-size:16px!important;}"
            + ".container{padding:0.8rem!important;}"
            + ".g2{grid-template-columns:1fr!important;}"
            + ".stats{grid-template-columns:repeat(2,1fr)!important;}"
            + ".steps{overflow-x:auto;-webkit-overflow-scrolling:touch;}"
            + ".step{min-width:80px;}"
            + ".tabs{overflow-x:auto;flex-wrap:nowrap;}"
            + ".tab{min-width:fit-content;}"
            + "';"
            + "document.head.appendChild(s);"
            // Ganti fungsi copy agar pakai Android native clipboard
            + "window.copyNative=function(t){"
            + "  if(window.Android)window.Android.copy(t);"
            + "  else{var d=document.createElement('textarea');d.value=t;"
            + "       document.body.appendChild(d);d.select();document.execCommand('copy');document.body.removeChild(d);}"
            + "};"
            + "})();";
        wv.evaluateJavascript(js, null);
    }

    private void open(String url) {
        if (!connected()) { showErr("Tidak ada koneksi internet."); return; }
        String u = url.trim();
        if (!u.startsWith("http")) u = "http://" + u;
        wv.loadUrl(u);
    }

    private void showSetupDialog() {
        View v   = LayoutInflater.from(this).inflate(R.layout.dialog_setup, null);
        EditText et = v.findViewById(R.id.etUrl);
        String cur  = prefs.getString(PREF_URL, "");
        if (!cur.isEmpty()) et.setText(cur);

        new AlertDialog.Builder(this)
            .setTitle("Setup URL Gateway")
            .setView(v)
            .setCancelable(!cur.isEmpty())
            .setPositiveButton("Simpan & Buka", (d, w) -> {
                String url = et.getText().toString().trim();
                if (url.isEmpty()) { toast("URL tidak boleh kosong"); return; }
                prefs.edit().putString(PREF_URL, url).apply();
                open(url);
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    private void showErr(String msg) {
        errLayout.setVisibility(View.VISIBLE);
        wv.setVisibility(View.GONE);
        errMsg.setText(msg);
    }

    public void onRetry(View v) {
        errLayout.setVisibility(View.GONE);
        wv.setVisibility(View.VISIBLE);
        open(prefs.getString(PREF_URL, ""));
    }

    public void onChangeUrl(View v) { showSetupDialog(); }

    private boolean connected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); }

    @Override
    public boolean onKeyDown(int kc, KeyEvent ev) {
        if (kc == KeyEvent.KEYCODE_BACK) {
            if (wv.canGoBack()) { wv.goBack(); }
            else {
                new AlertDialog.Builder(this)
                    .setTitle("Keluar?")
                    .setMessage("Tutup TZ Gateway?")
                    .setPositiveButton("Ya", (d, w) -> finish())
                    .setNegativeButton("Tidak", null)
                    .show();
            }
            return true;
        }
        return super.onKeyDown(kc, ev);
    }

    // ── Bridge JavaScript → Android ──────────────────────
    class Bridge {
        @android.webkit.JavascriptInterface
        public void copy(String text) {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("gw", text));
            runOnUiThread(() -> toast("Disalin!"));
        }

        @android.webkit.JavascriptInterface
        public void vibrate() {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null) vib.vibrate(40);
        }

        @android.webkit.JavascriptInterface
        public void changeUrl() { runOnUiThread(() -> showSetupDialog()); }

        @android.webkit.JavascriptInterface
        public void reload() {
            runOnUiThread(() -> {
                errLayout.setVisibility(View.GONE);
                wv.setVisibility(View.VISIBLE);
                wv.reload();
            });
        }

        @android.webkit.JavascriptInterface
        public String getUrl() { return prefs.getString(PREF_URL, ""); }
    }
}
